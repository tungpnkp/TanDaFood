<!--offcanvas menu area start-->
<div class="off_canvars_overlay">

</div>
<div class="offcanvas_menu">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="canvas_open">
                    <a href="javascript:void(0)"><i class="icon-menu"></i></a>
                </div>
                <div class="offcanvas_menu_wrapper">
                    <div class="canvas_close">
                        <a href="javascript:void(0)"><i class="icon-x"></i></a>
                    </div>
                    <div class="header_social text-right">
                        <ul>
                            <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-twitter"></i></a></li>
                            <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-googleplus-outline"></i></a></li>
                            <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-youtube-outline"></i></a></li>
                            <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-facebook"></i></a></li>
                            <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-instagram-outline"></i></a></li>
                        </ul>
                    </div>

                    <div class="call-support">
                        <p><a href="tel:(08)23456789">(+84) 83 215 2020</a>Hỗ trợ khách hàng</p>
                    </div>
                    <div id="menu" class="text-left ">
                        <ul class="offcanvas_main_menu">
                            <li class="menu-item-has-children active">
                                <a href="/index.html">Trang chủ</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="#">Truyền thông</a>
                                <ul class="sub-menu">
                                    <li class="menu-item-has-children">
                                        <a href="/tin-tuc.html">Tin tức và sự kiện</a>

                                    </li>
                                    <li class="menu-item-has-children">
                                        <a href="/blog.html">Bài viết</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="#">Giới thiệu</a>
                                <ul class="sub-menu">
                                    <li><a href="/gioi-thieu.html">Giới thiệu chung</a></li>
                                    <li><a href="/tuyen-dung.html">Tuyền dụng</a></li>
                                    <li><a href="/khach-hang-danh-gia.html">Khách hàng đánh giá</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="/he-thong-phan-phoi.html">Hệ thống phân phối </a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="/contact.html">Liên hệ</a>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas_footer">
                        <span><a href="#"><i class="fa fa-envelope-o"></i> htxnuibavi@gmail.com</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--offcanvas menu area end-->

<header>
    <div class="main_header">
        <div class="header_top">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-6">
                    </div>
                    <div class="col-lg-6">
                        <div class="header_social text-right">
                            <ul>
                                <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-googleplus-outline"></i></a></li>
                                <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-youtube-outline"></i></a></li>
                                <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-facebook"></i></a></li>
                                <li><a href="https://www.facebook.com/htxnuibavi/"><i class="ion-social-instagram-outline"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header_middle">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-2 col-md-3 col-sm-3 col-3">
                        <div class="logo">
                            <a href="/index.html"><img alt="Sơn Tinh Food - Đặc sản Núi Ba Vì" src="/image/defaut/logo_600_400.jpg" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="call-support">
                            <p><a href="tel:(08)23456789">(+84) 83 215 2020</a>Hỗ trợ khách hàng</p>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-6 col-sm-7 col-8">
                        <div class="header_right_info">
                            <div class="search_container mobail_s_none">
                                <form action="#">
                                    <div class="search_box">
                                        <input placeholder="Tìm kiếm sản phẩm..." type="text">
                                        <button type="submit"><span class="lnr lnr-magnifier"></span></button>
                                    </div>
                                </form>
                            </div>
                            @php
                                $cart      = Cart::content();
                            @endphp
                            <div class="header_account_area">
                                <div class="header_account_list  mini_cart_wrapper">
                                    <a href="javascript:void(0)"><span class="lnr lnr-cart shopping-cart"></span><span class="item_count" id="count_cart">{{ Cart::instance('default')->count() }}</span></a>
                                    <!--mini cart-->
                                    <div class="mini_cart">
                                        <div class="cart_gallery" id="cart-sidebar">
                                            <div class="cart_close">
                                                <div class="cart_text">
                                                    <h3>Sản phẩm</h3>
                                                </div>
                                                <div class="mini_cart_close">
                                                    <a href="javascript:void(0)"><i class="icon-x"></i></a>
                                                </div>
                                            </div>
                                            @if (count($cart) ==0)
                                                <div class="cart_item">
                                                    <div style="text-align: center;">Giỏ hàng trống</div>
                                                </div>
                                            @else
                                                @foreach($cart as $item)
                                                    @php
                                                        $product = App\Models\ShopProduct::find($item->id);
                                                    @endphp
                                                    <div class="cart_item">
                                                        <div class="cart_img">
                                                            <a href="#"><img src="{{ '/documents/website/'. $product->image}}" alt="{{ $item->name }}"></a>
                                                        </div>
                                                        <div class="cart_info">
                                                            <a href="#">{{$product->title}}</a>
                                                            <p>{{ $item->qty }} x <span> {{ number_format($item->price) }} </span></p>
                                                        </div>
                                                        <div class="cart_remove">

                                                            <a href="{{"/removeItem/".$item->rowId}}" title="Xóa" class="remove-cart"><i class="icon-x"></i></a>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @endif
                                        </div>
                                        <div class="mini_cart_table">
                                            <div class="cart_table_border">
                                                <div class="cart_total">
                                                    <span>Tổng số tiền thanh toán:</span>
                                                    <span class="price subtotal">{{ number_format(Cart::subtotal()) }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mini_cart_footer">
                                            <div class="cart_button">
                                                <a href="/cart.html"><i class="fa fa-shopping-cart"></i> Giỏ hàng</a>
                                            </div>
                                            <div class="cart_button">
                                                <a href="/checkout.html"><i class="fa fa-sign-in"></i> Thanh toán</a>
                                            </div>

                                        </div>
                                    </div>
                                    <!--mini cart end-->
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="header_bottom sticky-header">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6 mobail_s_block">
                        <div class="search_container">
                            <form action="#">
                                <div class="search_box">
                                    <input placeholder="Search product..." type="text">
                                    <button type="submit"><span class="lnr lnr-magnifier"></span></button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="categories_menu">
                            <div class="categories_title">
                                <h2 class="categori_toggle">DANH MỤC</h2>
                            </div>
                            <div class="categories_menu_toggle">
                                <ul>
                                    <li ><a href="/danh-muc/1.html">Rau sạch</a></li>
                                    <li ><a href="/danh-muc/2.html">Thịt sạch</a></li>
                                    <li ><a href="/danh-muc/3.html">Sữa tươi</a></li>
                                    <li><a href="/danh-muc/4.html">Đồ ăn nhanh</a></li>
                                    <li><a href="/danh-muc/5.html"> Thủy sản</a></li>
                                    <li><a href="/danh-muc/6.html"> Trái cây</a></li>
                                    <li><a href="/danh-muc/7.html"> Đồ khô</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <!--main menu start-->
                        <div class="main_menu menu_position">
                            <nav>
                                <ul>
                                    <li><a class="active"  href="/index.html">Trang chủ</a></li>
                                    <li>
                                        <a href="/blog.html">
                                            Truyền thông
{{--                                            <i class="fa fa-angle-down"></i>--}}
                                        </a>
{{--                                        <ul class="sub_menu pages">--}}
{{--                                            <li><a href="/tin-tuc.html">Tin tức và sự kiện</a></li>--}}
{{--                                            <li><a href="/blog.html">Bài viết</a></li>--}}
{{--                                        </ul>--}}
                                    </li>
                                    <li>
                                        <a href="/gioi-thieu.html">Giới thiệu <i class="fa fa-angle-down"></i></a>
                                        <ul class="sub_menu pages">
                                            <li><a href="/gioi-thieu.html">Giới Thiệu Chung</a></li>
                                            <li><a href="/tuyen-dung.html">Tuyển Dụng</a></li>
                                            <li><a href="/khach-hang-danh-gia.html">Khách Hàng Đánh giá</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="/he-thong-phan-phoi.html">Hệ thống phân phối</a></li>
                                    <li><a href="/contact.html">Liên hệ</a></li>
                                </ul>
                            </nav>
                        </div>
                        <!--main menu end-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>