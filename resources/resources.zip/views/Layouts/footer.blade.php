<footer class="footer_widgets">
    <hr>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v13.0" nonce="l2OgwP0k"></script>
    <div class="footer_top">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-12 col-sm-4">
                    <div class="widgets_container contact_us">
                        <div class="footer_logo">
                            <a href="index.html"><img alt="Sơn Tinh Food - Đặc sản Núi Ba Vì" src="/image/defaut/logo_600_400.jpg" alt=""></a>
                        </div>
                        <p><span>Địa chỉ: Thái Hòa, Ba Vì, Hà Nội</span> </p>
                        <p><span>Email:</span> <a href="#">htxnuibavi@gmail.com</a></p>
                        <p><span>Liên hệ:</span> <a href="tel:(+84)832152020">(+84) 83 215 2020</a> </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-8">
                    <div class="widgets_container widget_menu">
                        <h3>Giới thiệu</h3>
                        <div class="footer_menu">

                            <ul>
                                <li><a href="/gioi-thieu.html">Giới thiệu chung</a></li>
                                <li><a href="/tin-tuc.html">Tin tức và sự kiện</a></li>
                                <li><a href="/blog.html">bài viết</a></li>
                                <li><a href="/tuyen-dung.html">Tuyển dụng</a></li>
                                <li><a href="/khach-hang-danh-gia.html">Khách hàng đánh giá</a></li>
                                <li><a href="/sitemap.html">Site Map</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-4">
                    <div class="widgets_container widget_menu">
                        <h3>Quy định và chính sách</h3>
                        <div class="footer_menu">
                            <ul>
                                <li><a href="#">Hướng dẫn đặt hàng</a></li>
                                <li><a href="/van-chuyen-thanh-toan.html">Vận chuyển và Thanh toán</a></li>
                                <li><a href="/chinh-sach-bao-hanh.html">Chính sách Bảo hành</a></li>
                                <li><a href="/chinh-sach-bao-mat.html">Chính sách bảo mật thông tin</a></li>
                                <li><a href="/chinh-sach-khach-hang.html">Chính sách Khách hàng</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-8">
                    <h3 class="title_footer">Fanpage<a class="expander visible-xs" href="#TabBlock-4"></a></h3>
                    <div class="tabBlock" id="TabBlock-4">
                        <div class="fb-page" data-href="https://www.facebook.com/T%E1%BA%A2N-%C4%90%C3%80-FOOD-S%E1%BA%A1ch-T%E1%BB%AB-N%C3%B4ng-Tr%E1%BA%A1i-%C4%90%E1%BA%BFn-B%C3%A0n-%C4%82n-101471005872661/about/?ref=page_internal" data-tabs="messages" data-width="" data-height="150" data-small-header="false" data-adapt-container-width="false" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/T%E1%BA%A2N-%C4%90%C3%80-FOOD-S%E1%BA%A1ch-T%E1%BB%AB-N%C3%B4ng-Tr%E1%BA%A1i-%C4%90%E1%BA%BFn-B%C3%A0n-%C4%82n-101471005872661/about/?ref=page_internal" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/T%E1%BA%A2N-%C4%90%C3%80-FOOD-S%E1%BA%A1ch-T%E1%BB%AB-N%C3%B4ng-Tr%E1%BA%A1i-%C4%90%E1%BA%BFn-B%C3%A0n-%C4%82n-101471005872661/about/?ref=page_internal">TẢN ĐÀ FOOD - Sạch Từ Nông Trại Đến Bàn Ăn</a></blockquote></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer_bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-7">
                    <div class="copyright_area">
                        <p>Copyright  © 2022  <a href="#">TungPn</a>  . All Rights Reserved.Design by  <a href="#">TungPN</a></p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-5">
{{--                    <div class="footer_payment">--}}
{{--                        <ul>--}}
{{--                            <li><a href="#"><img src="assets/img/icon/paypal1.jpg" alt=""></a></li>--}}
{{--                            <li><a href="#"><img src="assets/img/icon/paypal2.jpg" alt=""></a></li>--}}
{{--                            <li><a href="#"><img src="assets/img/icon/paypal3.jpg" alt=""></a></li>--}}

{{--                            <li><a href="#"><img src="assets/img/icon/paypal4.jpg" alt=""></a></li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
                </div>
            </div>
        </div>
    </div>

</footer>