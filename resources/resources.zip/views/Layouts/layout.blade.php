<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sơn Tinh Food - Thực Phẩm Sạch Ba Vì</title>
    <meta name="description" content="Không giống như bao bạn bè đồng trang lứa, sau khi tốt nghiệp bằng cử nhân ngành Điều tra, tôi chọn về quê hương Ba Vì xứ Đoài lập nghiệp, cống hiến sức trẻ vì sự bình yên cuộc sống
Quê hương của tôi - núi Tản sông Đà có không khí trong lành, nguồn nước sạch, cây trái trù phú quanh năm và đặc biệt con người ở đây đều rất chân thật, thân thiện và hiền lành.
Chúng tôi chọn nguồn nguyên liệu sạch, có sẵn tại địa phương. Lúc đầu thật sự mọi thứ rất gian nan & vất vả, là tay ngang bước sang mảng thực phẩm, chỉ có tình yêu đối với quê hương, ý chí mong muốn được mang nguồn dinh dưỡng từ thực phẩm an toàn đến mọi người và nâng cao giá trị nông sản giúp người nông dân là động lực thôi thúc tôi phải thực sự  nghiêm túc với dự án này.
Mong sao các sản phẩm Nông sản sạch và Chất lượng thật sự của Sơn Tinh FOOD sẽ chạm đến nhiều người tiêu dùng thông thái trên khắp mọi miền, giúp đỡ được nhiều hơn nữa bà con nông dân địa phương.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Sơn Tinh Food, SonTinhFood, Núi Ba Vì, NuiBaVi, Thực phẩm sạch, Rau sạch, Thịt sạch, Sữa Tươi, Thực phẩm Ba Vì, Thực phẩm Sơn Tinh">
    <!-- Favicon -->
    <link rel="shortcut icon" alt="Sơn Tinh Food - Đặc sản Núi Ba Vì" type="image/x-icon" href="/image/defaut/logo2.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="/assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="/assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="/assets/css/font.awesome.css">
    <!--ionicons css-->
    <link rel="stylesheet" href="/assets/css/ionicons.min.css">
    <!--linearicons css-->
    <link rel="stylesheet" href="/assets/css/linearicons.css">
    <!--animate css-->
    <link rel="stylesheet" href="/assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="/assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="/assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="/assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">

    @yield('Stylesheet')

    <!--modernizr min js here-->
    <script src="/assets/js/vendor/modernizr-3.7.1.min.js"></script>
</head>

<body>

<div class="header-content">
    @yield('header-content')
</div>
<!--header area end-->

<div class="main-content">
    @yield('main-content')
</div>


<!--footer area start-->
<div class="footer-content">
    @yield('footer-content')
</div>
<!--footer area end-->


<!-- JS
============================================ -->
<!--jquery min js-->
<script src="/assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="/assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="/assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="/assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="/assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="/assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="/assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="/assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="/assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="/assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="/assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="/assets/js/slinky.menu.js"></script>
<!--instagramfeed menu js-->
<script src="/assets/js/jquery.instagramFeed.min.js"></script>
<!-- tippy bundle umd js -->
<script src="/assets/js/tippy-bundle.umd.js"></script>
<!-- Plugins JS -->
<script src="/assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="/assets/js/main.js"></script>

@yield('Script')

<script type="text/javascript">
    function formatNumber (num) {
        return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
    }
    $('#shipping').change(function(){
        $('#total').html(formatNumber(parseInt({{ Cart::subtotal() }})+ parseInt($('#shipping').val())));
    });
</script>

<script type="text/javascript">
    function addToCart(id,instance = null){
        $.ajax({
            url: '/addToCart',
            type: 'POST',
            dataType: 'json',
            data: {id: id,instance:instance, _token:'{{ csrf_token() }}'},
            success: function(data){
                console.log(data)
                flg= parseInt(data.flg);
                if(flg ===1)
                {
                    setTimeout(function () {
                        if(data.instance =='default'){
                            $('#count_cart').html(data.count_cart);
                            $('#cart-sidebar').html(data.htmlCart);
                            $('.subtotal').html(data.subtotal);
                            alert('Sản phẩm đã được thêm vào giỏ hàng thành công')
                        }
                    }, 1000);
                }else{
                    alert(data.error);
                }

            }
        });

    }

</script>
</body>

</html>