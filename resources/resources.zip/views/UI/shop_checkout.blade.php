@extends('Layouts.layout')

@section('header-content')
    @include('Layouts.header')
@endsection

@section('footer-content')
    @include('Layouts.footer')
@endsection

@section('main-content')
    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <h1>Thanh toán</h1>
                        <ul>
                            <li><a href="/index.html">Trang chủ</a></li>
                            <li><a href="/checkout.html">Thanh toán</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->
    @if(count($cart) == 0)
        <div class="error_section">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="error_form">
                            <p>Giỏ hàng trống</p>
                            <a href="/">Tiếp tục mua hàng</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
    <!--Checkout page section-->
    <div class="Checkout_section mt-70">
        <div class="container">
            <div class="row">
{{--                <div class="col-12">--}}
{{--                    <div class="user-actions">--}}
{{--                        <h3>--}}
{{--                            <i class="fa fa-file-o" aria-hidden="true"></i>--}}
{{--                            Returning customer?--}}
{{--                            <a class="Returning" href="#checkout_login" data-bs-toggle="collapse" aria-expanded="true">Click here to login</a>--}}

{{--                        </h3>--}}
{{--                        <div id="checkout_login" class="collapse" data-parent="#accordion">--}}
{{--                            <div class="checkout_info">--}}
{{--                                <form action="#">--}}
{{--                                    <div class="form_group">--}}
{{--                                        <label>Username or email <span>*</span></label>--}}
{{--                                        <input type="text">--}}
{{--                                    </div>--}}
{{--                                    <div class="form_group">--}}
{{--                                        <label>Password  <span>*</span></label>--}}
{{--                                        <input type="text">--}}
{{--                                    </div>--}}
{{--                                    <div class="form_group group_3 ">--}}
{{--                                        <button type="submit">Login</button>--}}
{{--                                        <label for="remember_box">--}}
{{--                                            <input id="remember_box" type="checkbox">--}}
{{--                                            <span> Remember me </span>--}}
{{--                                        </label>--}}
{{--                                    </div>--}}
{{--                                    <a href="#">Lost your password?</a>--}}
{{--                                </form>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>
            <div class="checkout_form">
                <form method="POST" action="/storeCart">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <h3>Thông tin</h3>
                            <div class="row">

                                <div class="col-lg-12 mb-20">
                                    <label>Tên:  <span>*</span></label>
                                    <input  name="toname" placeholder="Tên người nhận" type="text" required>
                                    @if($errors->has('toname'))
                                        <span class="help-block">{{ $errors->first('toname') }}</span>
                                    @endif
                                </div>

                                <div class="col-12 mb-20">
                                    <label>Địa chỉ:  <span>*</span></label>
                                    <input name="address1" type="text" placeholder="Số nhà, tên đường" required>
                                    @if($errors->has('address1'))
                                        <span class="help-block">{{ $errors->first('address1') }}</span>
                                    @endif
                                </div>
                                <div class="col-12 mb-20">
                                    <input name="address2" type="text" placeholder="Quận/Huyện, Thành Phố">
                                    @if($errors->has('address2'))
                                        <span class="help-block">{{ $errors->first('address2') }}</span>
                                    @endif
                                </div>

                                <div class="col-lg-6 mb-20">
                                    <label>Số điện thoại: <span>*</span></label>
                                    <input name="phone" type="text" placeholder="Số điện thoại">
                                    @if($errors->has('phone'))
                                        <span class="help-block">{{ $errors->first('phone') }}</span>
                                    @endif
                                </div>
{{--                                <div class="col-lg-6 mb-20">--}}
{{--                                    <label>Địa chỉ Email  <span>*</span></label>--}}
{{--                                    <input type="text" name="email">--}}
{{--                                </div>--}}
                                <div class="col-12">
                                    <div class="order-notes">
                                        <label  class="control-label"><i class="fa fa-file-image-o"></i> Ghi chú đơn hàng:</label>
                                        <textarea rows="5" name="comment" placeholder="Thời gian nhận, địa điểm...."></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <h3>Hóa đơn</h3>
                            <div class="order_table table-responsive">
                                <table>
                                    <thead>
                                    <tr>
                                        <th>Sản phẩm</th>
                                        <th>Giá</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($cart as $item)
                                        @php
                                            $n = (isset($n)?$n:0);
                                            $n++;
                                            $product = App\Models\ShopProduct::find($item->id);
                                        @endphp
                                        <tr>
                                            <td> {{$product->name}} <strong> X {{$item->qty}}</strong></td>
                                            <td> {{number_format($item->subtotal)}} Đ</td>
                                        </tr>
                                    @endforeach
                                    <tfoot>
                                    <tr>
                                        <th>Hóa đơn</th>
                                        <td>{{number_format($totalPaid)}} Đ</td>
                                    </tr>
                                    <tr>
                                        <th>Phí giao hàng</th>
                                        <td>Sẽ thông báo sau</td>
                                    </tr>
                                    <tr class="order_total">
                                        <th>Tổng</th>
                                        <td><strong>{{number_format($totalPaid)}} Đ</strong></td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <div class="payment_method">
                                <div class="order_button pull-right">
                                    <button  type="submit">Đặt đơn hàng</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>
    <!--Checkout page section end-->
    @endif
@endsection