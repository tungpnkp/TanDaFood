@extends('Layouts.layout')

@section('header-content')
    @include('Layouts.header')
@endsection

@section('main-content')
    <div>
        <section class="slider_section">
            <div class="slider_area owl-carousel">
                <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider1.jpg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="slider_content">
                                    <h1>Sơn Tinh Food - Đặc sản Núi Ba Vì</h1>
                                    <h2>Thực phẩm sạch</h2>
                                    <p>
                                       Thực phẩm 100% từ thiên nhiên
                                    </p>
                                    <a href="/shop.html">Xem thêm </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider2.jpg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="slider_content">
                                    <h1>Sơn Tinh Food - Đặc sản Núi Ba Vì</h1>
                                    <h2>Thực phẩm sạch</h2>
                                    <p>
                                        Thực phẩm 100% từ thiên nhiên
                                    </p>
                                    <a href="/shop.html">Xem thêm </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider3.jpg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="slider_content">
                                    <h1>Sơn Tinh Food - Đặc sản Núi Ba Vì</h1>
                                    <h2>Thực phẩm sạch</h2>
                                    <p>
                                        Thực phẩm 100% từ thiên nhiên
                                    </p>
                                    <a href="/shop.html">Xem thêm </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--slider area end-->

{{--        <!--shipping area start-->--}}
{{--        <div class="shipping_area">--}}
{{--            <div class="container">--}}
{{--                <div class="row">--}}
{{--                    <div class="col-lg-3 col-md-6">--}}
{{--                        <div class="single_shipping">--}}
{{--                            <div class="shipping_icone">--}}
{{--                                <img src="assets/img/about/shipping1.jpg" alt="">--}}
{{--                            </div>--}}
{{--                            <div class="shipping_content">--}}
{{--                                <h3>Miễn phí giao hàng</h3>--}}
{{--                                <p>Miễn phí giao hàng cho mọi đơn hàng từ ... đồng</p>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-lg-3 col-md-6">--}}
{{--                        <div class="single_shipping col_2">--}}
{{--                            <div class="shipping_icone">--}}
{{--                                <img src="assets/img/about/shipping2.jpg" alt="">--}}
{{--                            </div>--}}
{{--                            <div class="shipping_content">--}}
{{--                                <h3>Hỗ trợ 24/7</h3>--}}
{{--                                <p>Hỗ trợ khách hàng 24.7, 7 ngày / tuần</p>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-lg-3 col-md-6">--}}
{{--                        <div class="single_shipping col_3">--}}
{{--                            <div class="shipping_icone">--}}
{{--                                <img src="assets/img/about/shipping3.jpg" alt="">--}}
{{--                            </div>--}}
{{--                            <div class="shipping_content">--}}
{{--                                <h3>Hoàn trả</h3>--}}
{{--                                <p>Cam kết hoàn tiền nếu sản phẩm không như quảng cáo</p>--}}

{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-lg-3 col-md-6">--}}
{{--                        <div class="single_shipping col_4">--}}
{{--                            <div class="shipping_icone">--}}
{{--                                <img src="assets/img/about/shipping4.jpg" alt="">--}}
{{--                            </div>--}}
{{--                            <div class="shipping_content">--}}
{{--                                <h3>100% Thiên nhiên</h3>--}}
{{--                                <p>Cam kết các sản phẩm tươi sống ...</p>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--        <!--shipping area end-->--}}

        <p></p>
    <!--product banner area satrt-->
        <div class="product_banner_area mb-65">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section_title">
                            <h2>Sản phẩm nổi bật</h2>
                        </div>
                    </div>
                </div>
                <div class="product_banner_container">
                    <div class="row">
                        <div class="col-lg-4 col-md-5">
                            <div class="banner_thumb">
                                <a href="/shop.html"><img src="/assets/img/bg/banner4.jpg" alt="Sơn Tinh Food - Ẩm thực Ba Vì"></a>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-7">
                            <div class="small_product_area product_carousel  product_column2 owl-carousel">
                                @foreach($products as $key => $product)
                                    @if($key == 0 || $key%3 == 0)
                                    <div class="product_items">
                                    @endif
                                        <article class="single_product">
                                            <figure>
                                                <div class="product_thumb product-box-1">
                                                    <a class="primary_img" href="/product-details/{{$product->id}}.html"><img src="{{getProductImageFile('documents/website/'. $product->image)}}" alt="Sơn Tinh Food - {{$product->name}}"></a>
                                                </div>
                                                <figcaption class="product_content">
                                                    <h4 class="product_name"><a href="/product-details/{{$product->id}}.html">{{$product->name}}</a></h4>
                                                    <p><a href="/danh-muc/{{ $product->category->id}}.html">{{ $product->category->name }}</a></p>
                                                    <div class="action_links">
                                                        <ul>
                                                            <li class="add_to_cart"><a href="#" onClick="addToCart({{$product->id}})" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="price_box">
                                                        <span class="current_price">{{number_format($product->price)}} đ</span>
                                                    </div>
                                                </figcaption>
                                            </figure>
                                        </article>
                                    @if($key == 0 || $key%3 == 0)
                                    </div>
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--product banner area end-->

        <!--product area start-->
{{--        <div class="product_area  mb-64">--}}
{{--            <div class="container">--}}
{{--                <div class="row">--}}
{{--                    <div class="col-12">--}}
{{--                        <div class="product_header">--}}
{{--                            <div class="section_title">--}}
{{--                                <h2>Sản phẩm nổi bật</h2>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="product_container">--}}
{{--                    <div class="row">--}}
{{--                        <div class="col-12">--}}
{{--                            <div class="tab-content">--}}
{{--                                <div class="tab-pane fade show active" id="plant1" role="tabpanel">--}}
{{--                                    <div class="product_carousel product_column5 owl-carousel">--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                                <div class="tab-pane fade" id="plant2" role="tabpanel">--}}
{{--                                    <div class="product_carousel product_column5 owl-carousel">--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}

{{--                                    </div>--}}
{{--                                </div>--}}
{{--                                <div class="tab-pane fade" id="plant3" role="tabpanel">--}}
{{--                                    <div class="product_carousel product_column5 owl-carousel">--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}
{{--                                        <div class="product_items">--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_new">New</span>--}}
{{--                                                            <span class="label_sale">sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau cải</a></h4>--}}
{{--                                                        <p><a href="#">Rau sạch</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26000 đ</span>--}}
{{--                                                            <span class="old_price">30000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                            <article class="single_product">--}}
{{--                                                <figure>--}}
{{--                                                    <div class="product_thumb">--}}
{{--                                                        <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                                        <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                                        <div class="label_product">--}}
{{--                                                            <span class="label_sale">Sale</span>--}}
{{--                                                        </div>--}}
{{--                                                        <div class="action_links">--}}
{{--                                                            <ul>--}}
{{--                                                                <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                                <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                                <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                                <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                            </ul>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                    <figcaption class="product_content">--}}
{{--                                                        <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                                        <p><a href="#">Fruits</a></p>--}}
{{--                                                        <div class="price_box">--}}
{{--                                                            <span class="current_price">26 000 đ</span>--}}
{{--                                                            <span class="old_price">30 000 đ</span>--}}
{{--                                                        </div>--}}
{{--                                                    </figcaption>--}}
{{--                                                </figure>--}}
{{--                                            </article>--}}
{{--                                        </div>--}}

{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
        <!--product area end-->

        <!--banner area start-->
        <div class="banner_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="single_banner">
                            <div class="banner_thumb">
                                <a href="shop.html"><img src="assets/img/bg/banner1.jpg" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="single_banner">
                            <div class="banner_thumb">
                                <a href="shop.html"><img src="assets/img/bg/banner2.jpg" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--banner area end-->

        <!--product area start-->
{{--        <div class="product_area product_deals mb-65">--}}
{{--            <div class="container-fluid">--}}
{{--                <div class="row">--}}
{{--                    <div class="col-12">--}}
{{--                        <div class="section_title">--}}
{{--                            <h2>Sản phẩm mới</h2>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="product_container">--}}
{{--                    <div class="row">--}}
{{--                        <div class="col-12">--}}
{{--                            <div class="product_carousel product_column5 owl-carousel">--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="product_timing">--}}
{{--                                                <div data-countdown="2021/12/15"></div>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Thịt lợn</a></h4>--}}
{{--                                            <p><a href="#">Thịt</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">60 000 đ</span>--}}
{{--                                                <span class="old_price">100 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="product_timing">--}}
{{--                                                <div data-countdown="2021/12/15"></div>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Thịt lợn</a></h4>--}}
{{--                                            <p><a href="#">Thịt</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">60 000 đ</span>--}}
{{--                                                <span class="old_price">100 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="product_timing">--}}
{{--                                                <div data-countdown="2021/12/15"></div>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Thịt lợn</a></h4>--}}
{{--                                            <p><a href="#">Thịt</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">60 000 đ</span>--}}
{{--                                                <span class="old_price">100 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="product_timing">--}}
{{--                                                <div data-countdown="2021/12/15"></div>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Thịt lợn</a></h4>--}}
{{--                                            <p><a href="#">Thịt</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">60 000 đ</span>--}}
{{--                                                <span class="old_price">100 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="product_timing">--}}
{{--                                                <div data-countdown="2021/12/15"></div>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Thịt lợn</a></h4>--}}
{{--                                            <p><a href="#">Thịt</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">60 000 đ</span>--}}
{{--                                                <span class="old_price">100 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="product_timing">--}}
{{--                                                <div data-countdown="2021/12/15"></div>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Thịt lợn</a></h4>--}}
{{--                                            <p><a href="#">Thịt</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">60 000 đ</span>--}}
{{--                                                <span class="old_price">100 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
        <!--product area end-->

        <!--banner fullwidth area satrt-->
        <div class="banner_fullwidth">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="banner_full_content">
                            <p>Black Fridays !</p>
                            <h2>Giảm giá 50% <span>Tất cả các sản phẩm</span></h2>
                            <a href="/shop.html">Khám phá ngay</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--banner fullwidth area end-->


        <!--product area start-->
{{--        <div class="product_area mb-65">--}}
{{--            <div class="container">--}}
{{--                <div class="row">--}}
{{--                    <div class="col-12">--}}
{{--                        <div class="section_title">--}}
{{--                            <p>Recently added our store </p>--}}
{{--                            <h2>Mostview Products</h2>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="product_container">--}}
{{--                    <div class="row">--}}
{{--                        <div class="col-12">--}}
{{--                            <div class="product_carousel product_column5 owl-carousel">--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product20.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product21.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Quisque In Arcu</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$55.00</span>--}}
{{--                                                <span class="old_price">$235.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Cas Meque Metus</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$26.00</span>--}}
{{--                                                <span class="old_price">$362.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product17.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product16.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Aliquam Consequat</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$26.00</span>--}}
{{--                                                <span class="old_price">$362.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                                <span class="label_new">New</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Mauris Vel Tellus</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$48.00</span>--}}
{{--                                                <span class="old_price">$257.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product16.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product17.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Nunc Neque Eros</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$35.00</span>--}}
{{--                                                <span class="old_price">$245.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product18.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product19.jpg" alt=""></a>--}}
{{--                                            <div class="label_product">--}}
{{--                                                <span class="label_sale">Sale</span>--}}
{{--                                            </div>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Proin Lectus Ipsum</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$26.00</span>--}}
{{--                                                <span class="old_price">$362.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
        <!--product area end-->

        <!--blog area start-->
{{--        <section class="blog_section">--}}
{{--            <div class="container">--}}
{{--                <div class="row">--}}
{{--                    <div class="col-12">--}}
{{--                        <div class="section_title">--}}
{{--                            <h2>Tin tức</h2>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="row">--}}
{{--                    <div class="blog_carousel blog_column3 owl-carousel">--}}
{{--                        @foreach($news as $blog)--}}
{{--                            <div class="col-lg-3">--}}
{{--                                <article class="single_blog">--}}
{{--                                    <figure>--}}
{{--                                        <div class="blog_thumb">--}}
{{--                                            <a href="/blog-details/{{$blog->id}}.html"><img src="{{getBlogImageFile('documents/website/'.$blog->image)}}" alt="{{$blog->title}}"></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="blog_content">--}}
{{--                                            <div class="articles_date">--}}
{{--                                                <p>{{ date('Y-m-d', strtotime($blog->created_at)) }} | <a href="#">admin</a> </p>--}}
{{--                                            </div>--}}
{{--                                            <h4 class="post_title"><a href="/blog-details/{{$blog->id}}.html">{{$blog->title}}</a></h4>--}}
{{--                                            <p class="post_desc">{{$blog->description}}</p>--}}
{{--                                            <footer class="blog_footer">--}}
{{--                                                <a href="/blog-details/{{$blog->id}}.html">Xem thêm</a>--}}
{{--                                            </footer>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                            </div>--}}
{{--                        @endforeach--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </section>--}}
        <!--blog area end-->

        <!--blog area start-->
        <section class="blog_section">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section_title">
                            <h2>Bài viết giới thiệu sản phẩm</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="blog_carousel blog_column3 owl-carousel">
                        @foreach($blogs as $blog)
                            <div class="col-lg-3">
                                <article class="single_blog">
                                    <figure>
                                        <div class="blog_thumb">
                                            <a href="/blog-details/{{$blog->id}}.html"><img src="{{getBlogImageFile('documents/website/'.$blog->image)}}" alt="{{$blog->title}}"></a>
                                        </div>
                                        <figcaption class="blog_content">
                                            <div class="articles_date">
                                                <p>{{ date('Y-m-d', strtotime($blog->created_at)) }} | <a href="#">admin</a> </p>
                                            </div>
                                            <h4 class="post_title"><a href="/blog-details/{{$blog->id}}.html">{{$blog->title}}</a></h4>
                                            <p class="post_desc">{{$blog->description}}</p>
                                            <footer class="blog_footer">
                                                <a href="/blog-details/{{$blog->id}}.html">Xem thêm</a>
                                            </footer>
                                        </figcaption>
                                    </figure>
                                </article>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>
        <!--blog area end-->

        <!--custom product area start-->
{{--        <div class="custom_product_area">--}}
{{--            <div class="container">--}}
{{--                <div class="row">--}}
{{--                    <div class="col-12">--}}
{{--                        <div class="section_title">--}}
{{--                            <p>Recently added our store </p>--}}
{{--                            <h2>Featured Products</h2>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="row">--}}
{{--                    <div class="col-12">--}}
{{--                        <div class="small_product_area product_carousel product_column3 owl-carousel">--}}
{{--                            <div class="product_items">--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Aliquam Consequat</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$26.00</span>--}}
{{--                                                <span class="old_price">$362.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">26 000 đ</span>--}}
{{--                                                <span class="old_price">30 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product5.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product6.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Mauris Vel Tellus</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$56.00</span>--}}
{{--                                                <span class="old_price">$362.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                            </div>--}}
{{--                            <div class="product_items">--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product7.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product8.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Quisque In Arcu</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$20.00</span>--}}
{{--                                                <span class="old_price">$352.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product9.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product10.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Cas Meque Metus</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$72.00</span>--}}
{{--                                                <span class="old_price">$352.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product11.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product12.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Proin Lectus Ipsum</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$36.00</span>--}}
{{--                                                <span class="old_price">$282.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                            </div>--}}
{{--                            <div class="product_items">--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product13.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Mauris Vel Tellus</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$45.00</span>--}}
{{--                                                <span class="old_price">$162.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product10.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">26 000 đ</span>--}}
{{--                                                <span class="old_price">30 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product8.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product5.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">26 000 đ</span>--}}
{{--                                                <span class="old_price">30 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                            </div>--}}
{{--                            <div class="product_items">--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Aliquam Consequat</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$26.00</span>--}}
{{--                                                <span class="old_price">$362.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product11.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product10.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Rau Cải</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">26 000 đ</span>--}}
{{--                                                <span class="old_price">30 000 đ</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                                <article class="single_product">--}}
{{--                                    <figure>--}}
{{--                                        <div class="product_thumb">--}}
{{--                                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product9.jpg" alt=""></a>--}}
{{--                                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product8.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <figcaption class="product_content">--}}
{{--                                            <h4 class="product_name"><a href="product-details.html">Mauris Vel Tellus</a></h4>--}}
{{--                                            <p><a href="#">Fruits</a></p>--}}
{{--                                            <div class="action_links">--}}
{{--                                                <ul>--}}
{{--                                                    <li class="add_to_cart"><a href="cart.html" data-tippy="Thêm vào giỏ hàng" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"> <span class="lnr lnr-cart"></span></a></li>--}}
{{--                                                    <li class="quick_button"><a href="#" data-tippy="quick view" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true" data-bs-toggle="modal" data-bs-target="#modal_box" > <span class="lnr lnr-magnifier"></span></a></li>--}}
{{--                                                    <li class="wishlist"><a href="wishlist.html" data-tippy="Add to Wishlist" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-heart"></span></a></li>--}}
{{--                                                    <li class="compare"><a href="#" data-tippy="Add to Compare" data-tippy-placement="top" data-tippy-arrow="true" data-tippy-inertia="true"><span class="lnr lnr-sync"></span></a></li>--}}
{{--                                                </ul>--}}
{{--                                            </div>--}}
{{--                                            <div class="price_box">--}}
{{--                                                <span class="current_price">$56.00</span>--}}
{{--                                                <span class="old_price">$362.00</span>--}}
{{--                                            </div>--}}
{{--                                        </figcaption>--}}
{{--                                    </figure>--}}
{{--                                </article>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
        <!--custom product area end-->

        <!--brand area start-->
        <div class="brand_area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="brand_container owl-carousel ">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand1_st.jpg" alt="Sơn Tinh Food - Ẩm Thực Ba Vì"></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand1_st.jpg" alt="Sơn Tinh Food - Ẩm Thực Ba Vì"></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand1_st.jpg" alt="Sơn Tinh Food - Ẩm Thực Ba Vì"></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand1_st.jpg" alt="Sơn Tinh Food - Ẩm Thực Ba Vì"></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand1_st.jpg" alt="Sơn Tinh Food - Ẩm Thực Ba Vì"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--brand area end-->
    </div>
@endsection


@section('footer-content')
    @include('Layouts.footer')
@endsection


