@extends('Layouts.layout')

@section('header-content')
    @include('Layouts.header')
@endsection

@section('footer-content')
    @include('Layouts.footer')
@endsection

@section('main-content')
    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <h1>Giỏ hàng</h1>
                        <ul>
                            <li><a href="/index.html">Trang chủ</a></li>
                            <li><a href="/cart.html">Giỏ hàng</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    @if(count($cart) == 0)
        <div class="error_section">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="error_form">
                            <p>Giỏ hàng trống</p>
                            <a href="/">Tiếp tục mua hàng</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
    <!--shopping cart area start -->
    <div class="shopping_cart_area mt-70">
        <div class="container">
            <form action="#">
                <div class="row">
                    <div class="col-12">
                        <div class="table_desc">
                            <div class="cart_page">
                                <table>
                                    <thead>
                                    <tr>
                                        <th class="product_remove">Xóa</th>
                                        <th class="product_thumb">Ảnh</th>
                                        <th class="product_name">Sản phẩm</th>
                                        <th class="product-price">Giá</th>
                                        <th class="product_quantity">Số lượng</th>
                                        <th class="product_total">Tổng</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($cart as $item)
                                        @php
                                            $n = (isset($n)?$n:0);
                                            $n++;
                                            $product = App\Models\ShopProduct::find($item->id);
                                        @endphp
                                        <tr>
                                            <input type="hidden" id="cart-row-{{$item->id}}" value="{{$item->rowId}}">
                                            <td class="product_remove"><a onClick="return confirm('Bạn có muốn xóa sản phẩm này?')" title="Remove Item" alt="Remove Item" class="cart_quantity_delete" href="{{"/removeItem/" . $item->rowId}}"><i class="fa fa-trash-o"></i></a></td>
                                            <td class="product_thumb"><a target="_blank" href="/product-details/{{$product->id}}.html"><img src="/{{getProductImageFile('documents/website/'.$product->image)}}" alt="Sơn Tinh Food - {{$product->name}}"></a></td>
                                            <td class="product_name"><a href="/product-details/{{$product->id}}.html">{{$product->name}}</a></td>
                                            <td class="product-price">{{number_format($product->price)}} đ</td>
                                            <td class="product_quantity"><label>Số lượng</label>
                                                <input style="width: 70px;" type="number" onChange="updateCart({{$item->id}})" class="item-qty" id="item-{{$item->id}}" name="qty-{{$item->id}}" value="{{$item->qty}}"><span class="text-danger item-qty-{{$item->id}}" style="display: none;">
                                                </span>
                                            </td>
                                            <td class="product_total">{{number_format($item->subtotal)}} đ</td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="cart_submit">
                                <a href="/shop.html">
                                    <button>Tiếp tục mua hàng</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--coupon code area start-->
                <div class="coupon_area">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code left">
                                <h3>Mã giảm giá</h3>
                                <div class="coupon_inner">
                                    <p>Vui lòng nhập mã giảm giá ở đây .</p>
                                    <input placeholder="Mã giảm giá..." type="text">
                                    <button type="submit">Sử dụng</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code right">
                                <h3>Đơn hàng</h3>
                                <div class="coupon_inner">
                                    <div class="cart_subtotal">
                                        <p>Tổng</p>
                                        <p class="cart_amount">{{$totalPaid}}</p>
                                    </div>
                                    <div class="cart_subtotal ">
                                        <p>Nhân viên sẽ thông báo phí Giao hàng cho bạn ngay sau khi xác nhận đơn hàng</p>
                                    </div>

                                    <div class="cart_subtotal">
                                        <p>Tổng: </p>
                                        <p class="cart_amount">{{$totalPaid}}</p>
                                    </div>
                                    <div class="checkout_btn">
                                        <a href="/checkout.html">Thanh toán</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--coupon code area end-->
            </form>
        </div>
    </div>
    <!--shopping cart area end -->
    @endif

@endsection

@section('Script')
    <script type="text/javascript">
        function updateCart(id){
            var new_qty = $('#item-'+id).val();
            var row_id = $('#cart-row-'+id).val();
            $.ajax({
                url: '/updateToCart',
                type: 'POST',
                dataType: 'json',
                async: true,
                cache: false,
                data: {
                    id: id,
                    new_qty: new_qty,
                    rowId : row_id,
                    _token:'{{ csrf_token() }}'},
                success: function(data){
                    console.log(data);
                    flg= parseInt(data.flg);
                    if(flg === 1)
                    {
                        window.location.reload()
                    }else{
                        $('.item-qty-'+id).css('display','block').html(data.msg);
                    }

                }
            });
        }

        $('#coupon-button').click(function() {
            var coupon = $('#coupon-value').val();
            if(coupon==''){
                $('.coupon-msg').html('Bạn chưa nhập mã giảm giá').addClass('text-danger').show();
            }else{
                $('#coupon-button').button('loading');
                setTimeout(function() {
                    $.ajax({
                        url: '/usePromotion',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            code: coupon,
                            _token: "{{ csrf_token() }}",
                        },
                    })
                        .done(function(result) {
                            $('#coupon-value').val('');
                            $('.coupon-msg').removeClass('text-danger');
                            $('.coupon-msg').removeClass('text-success');
                            $('.coupon-msg').hide();
                            if(result.error ==1){
                                $('.coupon-msg').html(result.msg).addClass('text-danger').show();
                            }else{
                                $('#removeCoupon').show();
                                $('.coupon-msg').html(result.msg).addClass('text-success').show();
                                $('.showTotal').remove();
                                $('#showTotal').prepend(result.html);
                            }
                        })
                        .fail(function() {
                            console.log("error");
                        })

                    $('#coupon-button').button('reset');
                }, 2000);
            }
        });
        $('#removeCoupon').click(function() {
            $.ajax({
                url: '/usePromotion',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: "remove",
                    _token: "{{ csrf_token() }}",
                },
            })
                .done(function(result) {
                    $('#removeCoupon').hide();
                    $('#coupon-value').val('');
                    $('.coupon-msg').removeClass('text-danger');
                    $('.coupon-msg').removeClass('text-success');
                    $('.coupon-msg').hide();
                    $('.showTotal').remove();
                    $('#showTotal').prepend(result.html);
                })
                .fail(function() {
                    console.log("error");
                })
            // .always(function() {
            //     console.log("complete");
            // });
        });

    </script>
@endsection