$(document).ready(function() {
  $(window).load(function() {
    $('.main-footer').html('<div class="pull-right hidden-xs"><strong>Version</strong>&nbsp;&nbsp; 1.0</div><strong>Develop by <a href="#">TungPN</a></strong>');
  });
});